// 318844685 David Berkovits
package interfaces;

/**
 * The interface Hit notifier.
 *
 * @author David Berkovits ID : 318844685
 */
public interface HitNotifier {
    /**
     * Add hl as a listener to hit events.
     *
     * @param hl the HitListener
     */
    void addHitListener(HitListener hl);

    /**
     * Remove hl from the list of listeners to hit events.
     *
     * @param hl the hl
     */
    void removeHitListener(HitListener hl);
}